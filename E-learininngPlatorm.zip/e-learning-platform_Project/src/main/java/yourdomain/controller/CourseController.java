package yourdomain.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import yourdomain.ServiceLayer.CourseService;
import yourdomain.model.Course;
import yourdomain.model.User;

@Controller
public class CourseController {
	 @Autowired
	    private CourseService courseService;

	    @GetMapping("/courses")
	    public String listCourses(Model model) {
	        model.addAttribute("courses", courseService.getAllCourses());
	        return "courseList";
	    }

	    @GetMapping("/courseForm")
	    public String courseForm(Model model) {
	        model.addAttribute("course", new Course());
	        return "courseForm";
	    }

	    @PostMapping("/courseForm")
	    public String createCourse(@ModelAttribute Course course, @SessionAttribute("user") User user) {
	        course.setInstructorId(user.getId());
	        courseService.createCourse(course);
	        return "redirect:/courses";
	    }
	}